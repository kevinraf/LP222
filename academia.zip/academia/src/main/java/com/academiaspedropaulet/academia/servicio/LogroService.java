package com.academiaspedropaulet.academia.servicio;

import com.academiaspedropaulet.academia.modelo.Logro;
import com.academiaspedropaulet.academia.modelo.Logro;

import java.util.List;
import java.util.Map;

public interface LogroService extends CrudGenericoService<Logro, Long> {

}
