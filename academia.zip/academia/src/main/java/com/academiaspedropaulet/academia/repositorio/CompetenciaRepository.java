package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Competencia;

public interface CompetenciaRepository extends CrudGenericoRepository<Competencia, Long> {
}
