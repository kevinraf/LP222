package com.academiaspedropaulet.academia.servicio;

import com.academiaspedropaulet.academia.modelo.Seccion;
import com.academiaspedropaulet.academia.modelo.Seccion;

import java.util.List;
import java.util.Map;

public interface SeccionService extends CrudGenericoService<Seccion, Long> {

}
