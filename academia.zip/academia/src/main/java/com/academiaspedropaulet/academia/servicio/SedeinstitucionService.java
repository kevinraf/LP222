package com.academiaspedropaulet.academia.servicio;

import com.academiaspedropaulet.academia.modelo.Sedeinstitucion;
import com.academiaspedropaulet.academia.modelo.Sedeinstitucion;

import java.util.List;
import java.util.Map;

public interface SedeinstitucionService extends CrudGenericoService<Sedeinstitucion, Long> {

}
