package com.academiaspedropaulet.academia.servicio;


import com.academiaspedropaulet.academia.modelo.Institucion;
import com.academiaspedropaulet.academia.modelo.Institucion;

import java.util.List;
import java.util.Map;

public interface InstitucionService extends CrudGenericoService<Institucion, Long> {

}
