package com.academiaspedropaulet.academia.servicio;


import com.academiaspedropaulet.academia.modelo.MedioInteres;
import com.academiaspedropaulet.academia.modelo.MedioInteres;

import java.util.List;
import java.util.Map;

public interface MedioInteresService extends CrudGenericoService<MedioInteres, Long> {

}
