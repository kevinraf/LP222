package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Logro;

public interface LogroRepository extends CrudGenericoRepository<Logro, Long> {
}
