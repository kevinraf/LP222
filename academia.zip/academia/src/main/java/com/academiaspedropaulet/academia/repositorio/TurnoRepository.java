package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Turno;

public interface TurnoRepository extends CrudGenericoRepository<Turno, Long>{
}
