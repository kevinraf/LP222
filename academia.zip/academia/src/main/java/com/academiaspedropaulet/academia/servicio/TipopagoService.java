package com.academiaspedropaulet.academia.servicio;

import com.academiaspedropaulet.academia.modelo.Tipopago;
import com.academiaspedropaulet.academia.modelo.Tipopago;

import java.util.List;
import java.util.Map;

public interface TipopagoService extends CrudGenericoService<Tipopago, Long> {

}
