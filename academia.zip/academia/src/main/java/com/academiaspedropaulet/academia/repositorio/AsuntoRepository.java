package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Asunto;

public interface AsuntoRepository extends CrudGenericoRepository<Asunto, Long> {
}
