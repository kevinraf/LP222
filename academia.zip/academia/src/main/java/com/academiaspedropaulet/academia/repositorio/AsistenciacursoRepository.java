package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Asistenciacurso;

public interface AsistenciacursoRepository extends CrudGenericoRepository<Asistenciacurso, Long> {
}
