package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.EstadoEstudiante;

public interface EstadoEstudianteRepository extends CrudGenericoRepository<EstadoEstudiante, Long> {
}
