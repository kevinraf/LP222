package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Periodo;

public interface PeriodoRepository extends CrudGenericoRepository<Periodo, Long> {
}
