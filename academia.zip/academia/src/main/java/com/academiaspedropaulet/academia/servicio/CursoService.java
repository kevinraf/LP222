package com.academiaspedropaulet.academia.servicio;

import com.academiaspedropaulet.academia.modelo.Curso;
import com.academiaspedropaulet.academia.modelo.Curso;

import java.util.List;
import java.util.Map;

public interface CursoService extends CrudGenericoService<Curso, Long> {

}
