package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Comunicado;

public interface ComunicadoRepository extends CrudGenericoRepository<Comunicado, Long>{
}
