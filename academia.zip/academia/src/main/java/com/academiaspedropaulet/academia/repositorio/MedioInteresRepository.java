package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.MedioInteres;

public interface MedioInteresRepository extends CrudGenericoRepository<MedioInteres, Long> {
}
