package com.academiaspedropaulet.academia.servicio;

import com.academiaspedropaulet.academia.modelo.Pago;
import com.academiaspedropaulet.academia.modelo.Pago;

import java.util.List;
import java.util.Map;

public interface PagoService extends CrudGenericoService<Pago, Long> {

}
