package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Libreta;

public interface LibretaRepository extends CrudGenericoRepository<Libreta, Long> {
}
