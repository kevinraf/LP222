package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Insidencia;

public interface InsidenciaRepository extends CrudGenericoRepository<Insidencia, Long> {
}
