package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Pago;

public interface PagoRepository extends CrudGenericoRepository<Pago, Long> {
}
